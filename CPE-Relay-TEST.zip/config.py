cogs = [
    'Test1'
]

cog_config = {
    'Test1': {
        'target_channel_id': CHANNEL_ID, #Replace with the actual target channel ID for Test1
        'prefix': '.' #Replace with the desired prefix for Test1
    }
}

# Bot token
token = 'BOT_TOKEN'